<?php
header('Content-Type: application/json');

// Database connection
$conn = new mysqli('sql12.freesqldatabase.com', 'sql12760141', 'KTbyyRSfru', 'sql12760141');

if ($conn->connect_error) {
    echo json_encode(array('success' => false, 'message' => 'Database connection failed.'));
    exit;
}

// Query to fetch reservation details along with component name
$sql = "SELECT r.reg_no, c.component_name, r.user_id, r.user_name, r.email, r.phone_number, r.request_date 
        FROM reservations r 
        JOIN components c ON r.reg_no = c.reg_no 
        ORDER BY r.request_date DESC";


$result = $conn->query($sql);

$reservations = array(); 

while ($row = $result->fetch_assoc()) {
    $reservations[] = array(
        "reg_no" => $row["reg_no"],
        "component_name" => $row["component_name"],
        "user_name" => $row["user_name"],
        "email" => $row["email"],
        "phone" => $row["phone_number"], // ✅ Now included
        "request_date" => $row["request_date"]
    );
}

echo json_encode(array('success' => true, 'reservations' => $reservations));

$conn->close();
?>
