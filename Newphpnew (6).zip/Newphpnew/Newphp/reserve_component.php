<?php
header('Content-Type: application/json');
include 'db_connection.php';

$data = json_decode(file_get_contents("php://input"), true);
$reg_no = isset($data['reg_no']) ? $data['reg_no'] : '';

if (empty($reg_no)) {
    echo json_encode(array('success' => false, 'message' => 'Registration number is required.'));
    $conn->close();
    exit();
}

$query = "UPDATE components SET is_reserved = TRUE WHERE reg_no = ? AND is_reserved = FALSE";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $reg_no);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo json_encode(array('success' => true, 'message' => 'Component reserved successfully.'));
} else {
    echo json_encode(array('success' => false, 'message' => 'Component not found or already reserved.'));
}

$conn->close();
?>
