<?php
header('Content-Type: application/json');
include 'db_connection.php';

$lab_id = isset($_GET['lab_id']) ? intval($_GET['lab_id']) : 0;

if ($lab_id <= 0) {
    echo json_encode(array('success' => false, 'message' => 'Invalid lab ID.'));
    $conn->close();
    exit();
}

// Fetch components along with reservation details
$query = "SELECT components.reg_no, 
                 components.component_name, 
                 components.is_reserved, 
                 components.request_to_reserve, 
                 labs.name AS lab_name, 
                 COALESCE(reservations.user_id, NULL) AS user_id  -- ✅ Ensure user_id is returned
          FROM components
          JOIN labs ON components.lab_id = labs.id
          LEFT JOIN reservations ON components.reg_no = reservations.reg_no  -- ✅ Join with reservations
          WHERE components.lab_id = ?";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $lab_id);
$stmt->execute();
$result = $stmt->get_result();

$components = array();
while ($row = $result->fetch_assoc()) {
    $components[] = array(
        "reg_no" => $row['reg_no'],
        "component_name" => $row['component_name'],
        "is_reserved" => (bool) $row['is_reserved'],
        "request_to_reserve" => (bool) $row['request_to_reserve'],
        "lab_name" => $row['lab_name'],
        "user_id" => isset($row['user_id']) ? $row['user_id'] : null  // ✅ Ensure user_id is present
    );
}

// Debug: Print API response
echo json_encode(array('success' => true, 'components' => $components));
$conn->close();
?>
