<?php
header('Content-Type: application/json');

$host = "sql12.freesqldatabase.com";
$username = "sql12760141";
$password = "KTbyyRSfru";
$database = "sql12760141";

// Create database connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die(json_encode(array('success' => false, 'error' => 'Database connection failed')));
}

// Check if component_name parameter is set
if (!isset($_GET['component_name']) || empty($_GET['component_name'])) {
    echo json_encode(array('success' => false, 'error' => 'Missing component_name parameter'));
    $conn->close();
    exit();
}

$component_name = "%" . $_GET['component_name'] . "%"; // Prepare for LIKE query

// Use a prepared statement to prevent SQL injection
$sql = "SELECT 
            c.reg_no, 
            c.component_name, 
            c.is_reserved, 
            c.request_to_reserve, 
            l.id AS lab_id, 
            l.name AS lab_name, 
            d.id AS department_id, 
            d.name AS department_name, 
            f.id AS faculty_id, 
            f.name AS faculty_name
        FROM components c
        JOIN labs l ON c.lab_id = l.id
        JOIN departments d ON l.department_id = d.id
        JOIN faculties f ON d.faculty_id = f.id
        WHERE c.component_name LIKE ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $component_name);
$stmt->execute();
$result = $stmt->get_result();

$components = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Ensure boolean fields are properly formatted
        $components[] = array(
            "reg_no" => $row['reg_no'],
            "component_name" => $row['component_name'],
            "is_reserved" => (bool) $row['is_reserved'],
            "request_to_reserve" => (bool) $row['request_to_reserve'],
            "lab_id" => $row['lab_id'],
            "lab_name" => $row['lab_name'],
            "department_id" => $row['department_id'],
            "department_name" => $row['department_name'],
            "faculty_id" => $row['faculty_id'],
            "faculty_name" => $row['faculty_name']
        );
    }
    echo json_encode(array('success' => true, 'components' => $components));
} else {
    echo json_encode(array('success' => false, 'message' => 'No components found'));
}

$stmt->close();
$conn->close();
?>
