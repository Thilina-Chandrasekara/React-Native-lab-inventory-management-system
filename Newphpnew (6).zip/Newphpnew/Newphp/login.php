<?php
header('Content-Type: application/json');

// Database configuration
$host = 'sql12.freesqldatabase.com';
$db = 'sql12760141';
$user = 'sql12760141';
$pass = 'KTbyyRSfru';

// Connect to the database
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    echo json_encode(array('success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error));
    exit();
}

// Read input data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!isset($data['email'], $data['password'])) {
    echo json_encode(array('success' => false, 'message' => 'Missing email or password.'));
    exit();
}

$email = $data['email'];
$password = $data['password'];

// Query database
$stmt = $conn->prepare("SELECT id, first_name, last_name, email, password, phone_number, faculty FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password'])) {
        // Remove password from response
        unset($row['password']);

        // Explicitly ensure all fields exist in response
        $user = array(
            'id' => $row['id'],
            'first_name' => $row['first_name'],
            'last_name' => $row['last_name'],
            'email' => $row['email'],
            'phone' => $row['phone_number'],  // Ensure this matches the database column name
            'faculty' => $row['faculty']
        );

        echo json_encode(array('success' => true, 'user' => $user));
    } else {
        echo json_encode(array('success' => false, 'message' => 'Invalid password.'));
    }
} else {
    echo json_encode(array('success' => false, 'message' => 'User not found.'));
}

$stmt->close();
$conn->close();
?>
