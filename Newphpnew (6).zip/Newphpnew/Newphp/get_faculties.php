<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");

$servername = "sql12.freesqldatabase.com";
$username = "sql12760141";
$password = "KTbyyRSfru";
$dbname = "sql12760141";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(array("success" => false, "message" => "Database connection failed")));
}

$sql = "SELECT id, name FROM faculties"; // Ensure table name is correct
$result = $conn->query($sql);

$faculties = array(); // Use array() instead of []

while ($row = $result->fetch_assoc()) {
    $faculties[] = array("id" => $row["id"], "name" => $row["name"]);
}

echo json_encode(array("success" => true, "faculties" => $faculties));

$conn->close();
?>
