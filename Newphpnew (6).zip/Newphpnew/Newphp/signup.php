<?php
header('Content-Type: application/json');

// Database configuration
$host = 'sql12.freesqldatabase.com';
$db = 'sql12760141';
$user = 'sql12760141';
$pass = 'KTbyyRSfru';

// Connect to the database
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    echo json_encode(array('success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error));
    exit();
}

// Read input data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Check if required fields are set
if (!isset($data['first_name'], $data['last_name'], $data['email'], $data['password'], $data['phone'], $data['faculty'])) {
    echo json_encode(array('success' => false, 'message' => 'Missing required fields.'));
    exit();
}

$first_name = $data['first_name'];
$last_name = $data['last_name'];
$email = $data['email'];
$password = password_hash($data['password'], PASSWORD_BCRYPT);
$phone = $data['phone'];
$faculty = $data['faculty'];

// Insert user
$stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, password, phone_number, faculty) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssss", $first_name, $last_name, $email, $password, $phone, $faculty);

if ($stmt->execute()) {
    // Fetch the inserted user
    $user_id = $stmt->insert_id;
    $user = array(
        'id' => $user_id,
        'first_name' => $first_name,
        'last_name' => $last_name,
        'email' => $email,
        'phone' => $phone,
        'faculty' => $faculty
    );
    echo json_encode(array('success' => true, 'message' => 'User inserted successfully.', 'user' => $user));
} else {
    echo json_encode(array('success' => false, 'message' => 'Insert failed: ' . $stmt->error));
}

$stmt->close();
$conn->close();
?>
