<?php
header('Content-Type: application/json');
include 'db_connection.php';

$response = array(
    'faculties' => array(),
    'departments' => array(),
    'labs' => array(),
);

// Fetch faculties
$facultiesQuery = "SELECT * FROM faculties";
$facultiesResult = $conn->query($facultiesQuery);
while ($row = $facultiesResult->fetch_assoc()) {
    $response['faculties'][] = $row;
}

// Fetch departments
$departmentsQuery = "SELECT * FROM departments";
$departmentsResult = $conn->query($departmentsQuery);
while ($row = $departmentsResult->fetch_assoc()) {
    $response['departments'][] = $row;
}

// Fetch labs
$labsQuery = "SELECT * FROM labs";
$labsResult = $conn->query($labsQuery);
while ($row = $labsResult->fetch_assoc()) {
    $response['labs'][] = $row;
}

echo json_encode($response);
$conn->close();
?>
