<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include 'db_connection.php'; // Make sure it has correct DB credentials & OpenCon/CloseCon

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    echo json_encode(array("success" => false, "message" => "Only GET requests allowed."));
    exit;
}

if (!isset($_GET["reg_no"])) {
    echo json_encode(array("success" => false, "message" => "Missing component reg_no."));
    exit;
}

$reg_no = $_GET["reg_no"];

// Open DB connection
$conn = OpenCon();

// Secure the input
$reg_no = mysqli_real_escape_string($conn, $reg_no);

/**
 * We'll JOIN all the tables to get lab_name, department_name, and faculty_name
 * based on your existing relationships:
 *
 * components (lab_id) --> labs (id) --> departments (id) --> faculties (id)
 */
$query = "
    SELECT 
        c.reg_no,
        c.component_name,
        c.is_reserved,
        c.request_to_reserve,
        c.lab_id,
        l.name AS lab_name,
        d.name AS department_name,
        f.name AS faculty_name
    FROM components c
    JOIN labs l ON c.lab_id = l.id
    JOIN departments d ON l.department_id = d.id
    JOIN faculties f ON d.faculty_id = f.id
    WHERE c.reg_no = '$reg_no'
    LIMIT 1
";

$result = mysqli_query($conn, $query);

if (!$result) {
    // If the query itself fails (e.g. syntax error):
    echo json_encode(array(
        "success" => false,
        "message" => "Database query failed: " . mysqli_error($conn)
    ));
    CloseCon($conn);
    exit;
}

// Check if we got a matching row
if (mysqli_num_rows($result) > 0) {
    $component = mysqli_fetch_assoc($result);

    // Return the data in JSON format
    echo json_encode(array(
        "success" => true,
        "component" => $component
    ));
} else {
    // No rows found with that reg_no
    echo json_encode(array(
        "success" => false,
        "message" => "Component not found."
    ));
}

// Close DB connection
CloseCon($conn);
?>
