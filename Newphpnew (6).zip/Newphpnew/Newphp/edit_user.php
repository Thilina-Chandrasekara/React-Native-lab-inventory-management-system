<?php
header('Content-Type: application/json');

// Database configuration
$host = 'sql12.freesqldatabase.com';  // Change this to your database host
$db = 'sql12760141';  // Change this to your database name
$user = 'sql12760141';  // Change this to your database username
$pass = 'KTbyyRSfru';  // Change this to your database password

// Connect to the database
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    echo json_encode(array('success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error));
    exit();
}

// Read input data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validate input fields
if (!isset($data['id'], $data['first_name'], $data['last_name'], $data['phone'], $data['faculty'])) {
    echo json_encode(array('success' => false, 'message' => 'Missing required fields.'));
    exit();
}

$id = intval($data['id']);  // Ensure ID is an integer
$first_name = $conn->real_escape_string($data['first_name']);
$last_name = $conn->real_escape_string($data['last_name']);
$phone = $conn->real_escape_string($data['phone']);
$faculty = $conn->real_escape_string($data['faculty']);

// Update user information in the database
$stmt = $conn->prepare("UPDATE users SET first_name = ?, last_name = ?, phone_number = ?, faculty = ? WHERE id = ?");
$stmt->bind_param("ssssi", $first_name, $last_name, $phone, $faculty, $id);

if ($stmt->execute()) {
    echo json_encode(array('success' => true, 'message' => 'Profile updated successfully.'));
} else {
    echo json_encode(array('success' => false, 'message' => 'Update failed: ' . $stmt->error));
}

$stmt->close();
$conn->close();
?>
