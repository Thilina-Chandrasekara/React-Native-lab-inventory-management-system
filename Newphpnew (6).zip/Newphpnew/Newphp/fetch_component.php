<?php
include 'db_connection.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

if (isset($_GET['id'])) {
    $component_id = intval($_GET['id']);

    // Join the components with labs, departments, and faculties to fetch names.
    $query = "SELECT c.*, 
                     l.name AS lab_name, 
                     d.name AS department_name, 
                     f.name AS faculty_name
              FROM components c
              LEFT JOIN labs l ON c.lab_id = l.id
              LEFT JOIN departments d ON c.department_id = d.id
              LEFT JOIN faculties f ON c.faculty_id = f.id
              WHERE c.id = $component_id";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $component = mysqli_fetch_assoc($result);
        // Cast state fields to booleans.
        $component['is_reserved'] = ($component['is_reserved'] == 1);
        $component['request_to_reserve'] = ($component['request_to_reserve'] == 1);
        echo json_encode(array("success" => true, "component" => $component));
    } else {
        echo json_encode(array("success" => false, "message" => "Component not found"));
    }
} else {
    echo json_encode(array("success" => false, "message" => "No ID provided"));
}

mysqli_close($conn);
?>
