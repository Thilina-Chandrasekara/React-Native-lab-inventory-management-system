<?php
header('Content-Type: application/json');

// Get input data
$input = json_decode(file_get_contents('php://input'), true);

$reg_no = isset($input['reg_no']) ? $input['reg_no'] : '';
$user_id = isset($input['user_id']) ? $input['user_id'] : '';
$user_name = isset($input['user_name']) ? $input['user_name'] : '';
$email = isset($input['email']) ? $input['email'] : '';
$phone_number = isset($input['phone_number']) ? $input['phone_number'] : ''; // ✅ Added phone number

// Validate required fields
if (empty($reg_no) || empty($user_id) || empty($user_name) || empty($email) || empty($phone_number)) {
    echo json_encode(array('success' => false, 'message' => 'Missing required fields.'));
    exit;
}

// Database connection
$conn = new mysqli('sql12.freesqldatabase.com', 'sql12760141', 'KTbyyRSfru', 'sql12760141');

if ($conn->connect_error) {
    echo json_encode(array('success' => false, 'message' => 'Database connection failed.'));
    exit;
}

// Update components table to mark as requested
$update_sql = "UPDATE components SET request_to_reserve = 1 WHERE reg_no = ?";
$stmt = $conn->prepare($update_sql);
$stmt->bind_param('s', $reg_no);
$stmt->execute();
$stmt->close();

// Insert request details into reservations table
$insert_sql = "INSERT INTO reservations (reg_no, user_id, user_name, email, phone_number, request_date) 
               VALUES (?, ?, ?, ?, ?, NOW())";
$stmt = $conn->prepare($insert_sql);
$stmt->bind_param('sssss', $reg_no, $user_id, $user_name, $email, $phone_number);

if ($stmt->execute()) {
    echo json_encode(array('success' => true, 'message' => 'Reservation request submitted.'));
} else {
    echo json_encode(array('success' => false, 'message' => 'Failed to submit reservation request. Error: ' . $stmt->error));
}

$stmt->close();
$conn->close();
?>
