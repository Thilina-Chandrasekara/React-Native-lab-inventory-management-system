<?php
$host = "sql12.freesqldatabase.com";
$username = "sql12760141";
$password = "KTbyyRSfru";
$database = "sql12760141";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
