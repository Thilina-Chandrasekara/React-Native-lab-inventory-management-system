<?php
header('Content-Type: application/json');

// Decode JSON input
$input = json_decode(file_get_contents('php://input'), true);
$reg_no = isset($input['reg_no']) ? $input['reg_no'] : '';
$user_id = isset($input['user_id']) ? $input['user_id'] : '';

if (empty($reg_no) || empty($user_id)) {
    echo json_encode(array('success' => false, 'message' => 'Missing required fields.'));
    exit;
}

// Database connection
$conn = new mysqli('sql12.freesqldatabase.com', 'sql12760141', 'KTbyyRSfru', 'sql12760141');

if ($conn->connect_error) {
    echo json_encode(array('success' => false, 'message' => 'Database connection failed.'));
    exit;
}

// Check if the user owns the request
$check_sql = "SELECT * FROM reservations WHERE reg_no = ? AND user_id = ?";
$stmt = $conn->prepare($check_sql);
$stmt->bind_param('ss', $reg_no, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(array('success' => false, 'message' => 'Unauthorized request. You can only cancel your own reservations.'));
    exit;
}

// Delete reservation from the reservations table
$delete_sql = "DELETE FROM reservations WHERE reg_no = ? AND user_id = ?";
$delete_stmt = $conn->prepare($delete_sql);
$delete_stmt->bind_param('ss', $reg_no, $user_id);

if ($delete_stmt->execute()) {
    // Update the components table to remove reservation status
    $update_sql = "UPDATE components SET request_to_reserve = 0 WHERE reg_no = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param('s', $reg_no);
    $update_stmt->execute();
    $update_stmt->close();

    echo json_encode(array('success' => true, 'message' => 'Reservation request canceled.'));
} else {
    echo json_encode(array('success' => false, 'message' => 'Failed to cancel reservation request.'));
}

$delete_stmt->close();
$conn->close();
?>
